<?php $__env->startSection('title'); ?>
    Accounts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <li>
        <a href="<?php echo e(route('master-home')); ?>">Home</a>
    </li>
    <li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
        <a href="<?php echo e(route('master-item', ['name' => 'All'])); ?>">Items</a>
        <ul class="dropdown">
            <?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('master-item', ['name' => $c->name])); ?>"><?php echo e($c->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
    <li>
        <a href="<?php echo e(route('master-category')); ?>">Categories</a>
    </li>
    <li>
        <a href="<?php echo e(route('master-payment')); ?>">Payments</a>
    </li>
    <li class="has-dropdown active" style="color:rgba(255, 255, 255, 0.7)">
        <a href="<?php echo e(route('master-account', ['search'=>'All'])); ?>">Accounts</a>
        <ul class="dropdown">
            <li>
                <a href="<?php echo e(route('master-account', ['search'=>'Master'])); ?>">Master</a>
            </li>
            <li>
                <a href="<?php echo e(route('master-account', ['search'=>'User'])); ?>">User</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="<?php echo e(route('master-profile')); ?>">Profile</a>
    </li>
    <li>
        <a href="<?php echo e(route('master-profile')); ?>">LogOut</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('sukses')): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Yay...',
                text: '<?php echo e(Session::get('sukses')); ?>',
                customClass: {
                    confirmButton: 'btn btn-success',
                    container: 'my-swal'
                }
            });
        </script>
        <style>
            .my-swal .swal2-confirm {
                margin: 1em;
            }
        </style>
    <?php endif; ?>
    <div class="" id="itemList" style="margin-top: 15%">
        <table class="table" style="background-color: #1a1814">
            <tr style="font-weight: bold; color: white; border-bottom: 2px solid">
                <th style="border-right: 2px solid; border-left: 2px solid; text-align: center">Username</th>
                <th style="border-right: 2px solid; text-align: center">Display Name</th>
                <th style="border-right: 2px solid; text-align: center">Email</th>
                <th style="border-right: 2px solid; text-align: center">Tel.</th>
                <th style="border-right: 2px solid; text-align: center">Action</th>
            </tr>
            <?php $__currentLoopData = $listAccount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center" style="color: white; border-bottom: 2px solid">
                    <td style="border-right: 2px solid; border-left: 2px solid; vertical-align: middle">
                        <?php echo e($i->username); ?>

                    </td>
                    <td style="border-right: 2px solid; border-left: 2px solid; vertical-align: middle">
                        <?php echo e($i->display_name); ?>

                    </td>
                    <td style="border-right: 2px solid; border-left: 2px solid; vertical-align: middle">
                        <?php echo e($i->email); ?>

                    </td>
                    <td style="border-right: 2px solid; border-left: 2px solid; vertical-align: middle">
                        <?php echo e($i->tel); ?>

                    </td>
                    <td style="border-right: 2px solid; border-left: 2px solid; vertical-align: middle">
                        <?php if($i->role == "master"): ?>
                        <a class="btn btn-warning" href="<?php echo e(route('master-account-role', ['username' => $i->username])); ?>">
                            Change to User
                        </a>
                        <?php else: ?>
                            <a title="View Detail" class="btn btn-primary" href="<?php echo e(route('master-account', ['search' => $i->username])); ?>">
                                <i class="icon-eye"></i>
                            </a>
                            <a class="btn btn-success" href="<?php echo e(route('master-account-role', ['username' => $i->username])); ?>">
                                Change to Master
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.crud', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\master\account-show.blade.php ENDPATH**/ ?>