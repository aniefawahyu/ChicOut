<?php $__env->startSection('title'); ?>
    TastyPastries - <?php echo e(Auth::user()->display_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<li>
    <a href="<?php echo e(route('master-home')); ?>">Home</a>
</li>
<li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
    <a href="<?php echo e(route('master-item', ['name' => 'All'])); ?>">Items</a>
    <ul class="dropdown">
        <?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('master-item', ['name' => $c->name])); ?>"><?php echo e($c->name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</li>
<li>
    <a href="<?php echo e(route('master-category')); ?>">Categories</a>
</li>
<li>
    <a href="<?php echo e(route('master-payment')); ?>">Payments</a>
</li>
<li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
    <a href="<?php echo e(route('master-account', ['search'=>'All'])); ?>">Accounts</a>
    <ul class="dropdown">
        <li>
            <a href="<?php echo e(route('master-account', ['search'=>'Master'])); ?>">Master</a>
        </li>
        <li>
            <a href="<?php echo e(route('master-account', ['search'=>'User'])); ?>">User</a>
        </li>
    </ul>
</li>
<li class="active">
    <a href="<?php echo e(route('master-profile')); ?>">Profile</a>
</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 10%">
        <div class="page">
            <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger"><b>Logout</b></a>
            <?php if($errors->any()): ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: '<?php echo e($errors->first()); ?>',
                        customClass: {
                            confirmButton: 'btn btn-danger',
                            container: 'my-swal'
                        }
                    });
                </script>
                <style>
                    .my-swal .swal2-confirm {
                        margin: 1.25em;
                    }
                </style>
            <?php endif; ?>
            <?php if(Session::has('sukses')): ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Yay...',
                        text: '<?php echo e(Session::get('sukses')); ?>',
                        customClass: {
                            confirmButton: 'btn btn-success',
                            container: 'my-swal'
                        }
                    });
                </script>
                <style>
                    .my-swal .swal2-confirm {
                        margin: 1em;
                    }
                </style>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <form method="post">
                        <?php echo csrf_field(); ?>
                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username:</label>
                                <input type="text" name="username" class="form-control"
                                    value="<?php echo e(Auth::user()->username); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="display_name" class="form-label">Display Name:</label>
                                <input type="text" name="display_name" class="form-control"
                                    value="<?php echo e(Auth::user()->display_name); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="text" name="email" class="form-control"
                                    value="<?php echo e(Auth::user()->email); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Current Password:</label>
                                <input type="password" name="password" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="newPassword" class="form-label">New Password:</label>
                                <input type="password" name="newPassword" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="tel" class="form-label">Tel:</label>
                                <input type="text" name="tel" class="form-control" value="<?php echo e(Auth::user()->tel); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address:</label>
                                <input type="text" name="address" class="form-control"
                                    value="<?php echo e(Auth::user()->address); ?>">
                            </div>
                            <br>
                            <button type="submit" class="btn btn-success">Update</button>
                            <br><br>
                        </form>
                    </form>
                </div>
                <!-- Kolom Pertama: Profile Card -->
                <div class="col-md-6">
                    <div class="custom-card-history">
                        <div class="card-profile-kiri">
                            <img src="<?php echo e(asset('image/profile.svg')); ?>">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\master\profile.blade.php ENDPATH**/ ?>