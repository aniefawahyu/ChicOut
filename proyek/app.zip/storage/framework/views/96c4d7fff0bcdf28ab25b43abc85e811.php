<?php $__env->startSection('title'); ?>
    TastyPastries -
    <?php if($payment != null): ?>
        <?php echo e($payment->name); ?>

    <?php else: ?>
        Add Payment
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
<li>
    <a href="<?php echo e(route('master-home')); ?>">Home</a>
</li>
<li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
    <a href="<?php echo e(route('master-item', ['name' => 'All'])); ?>">Items</a>
    <ul class="dropdown">
        <?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('master-item', ['name' => $c->name])); ?>"><?php echo e($c->name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</li>
<li>
    <a href="<?php echo e(route('master-category')); ?>">Categories</a>
</li>
<li class="active">
    <a href="<?php echo e(route('master-payment')); ?>">Payments</a>
</li>
<li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
    <a href="<?php echo e(route('master-account', ['search'=>'All'])); ?>">Accounts</a>
    <ul class="dropdown">
        <li>
            <a href="<?php echo e(route('master-account', ['search'=>'Master'])); ?>">Master</a>
        </li>
        <li>
            <a href="<?php echo e(route('master-account', ['search'=>'User'])); ?>">User</a>
        </li>
    </ul>
</li>
<li>
    <a href="<?php echo e(route('master-profile')); ?>">Profile</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <?php if($errors->any()): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo e($errors->first()); ?>',
                customClass: {
                    confirmButton: 'btn btn-danger',
                    container: 'my-swal'
                }
            });
        </script>
        <style>
            .my-swal .swal2-confirm {
                margin: 1.25em;
            }
        </style>
    <?php endif; ?>

    <div class="container" style="margin-top: 15%">
        <?php if($payment != null): ?>
            <h1 style="color: white">Update <?php echo e($payment->name); ?></h1>
        <?php else: ?>
            <h1 style="color: white">Insert New Payment</h1>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-6">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if($payment != null): ?>
                        Name: <input type="text" name="name" id="name" class="form-control" value="<?php echo e($payment->name); ?>">
                        Image: <input type="text" name="img" id="img" class="form-control" value="<?php echo e($payment->img); ?>" placeholder="URL"><br>
                        <button type="submit" name="save" class="btn btn-success" value="<?php echo e($payment->ID_payments); ?>"><i class="icon-save"></i></button>
                    <?php else: ?>
                        Name: <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name')); ?>">
                        Image: <input type="text" name="img" id="img" class="form-control" value="<?php echo e(old('img')); ?>" placeholder="URL"><br>
                        <button type="submit" name="add" class="btn btn-success"><i class="icon-save"></i></button>
                    <?php endif; ?>
                </form>
            </div>
            Preview Image:
            <div class="col-md-6" style="background-color: white">
                <?php if($payment != null): ?>
                    <img id="newImage" src="<?php echo e($payment->img); ?>" alt="" style="width: 100%">
                <?php else: ?>
                    <img id="newImage" src="<?php echo e(old('img')); ?>" alt="" style="width: 100%">
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function () {
        $('#img').on('change', function () {
            updateImageSrc();
        });

        function updateImageSrc() {
            var newSrc = $('#img').val();
            $('#newImage').attr('src', newSrc);
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("layout.crud", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\master\payment-insert-update.blade.php ENDPATH**/ ?>