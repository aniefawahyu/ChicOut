<?php $__env->startSection('title'); ?>
    ChicOut - <?php echo e(Auth::user()->display_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <li>
        <a href="<?php echo e(url('ChicOut/Category/Men')); ?>">Men</a>
    </li>
    <li>
        <a href="<?php echo e(url('ChicOut/Category/Women')); ?>">Women</a>
    </li>
    <li class="has-dropdown">
        <a>More</a>
        <ul class="dropdown">
            <?php $__currentLoopData = $listMerch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(url('ChicOut/Category/' . $c['name'])); ?>"><?php echo e($c['name']); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'master'): ?>
            <li><a href="<?php echo e(route('master-home')); ?>">Master</a></li>
        <?php else: ?>
            <li><a href="<?php echo e(route('cart')); ?>">Cart</a></li>
            <li class="active"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 15%">
        <div class="page">
            <a href="<?php echo e(route('profile')); ?>" class="btn btn-primary"><i class="icon-back"></i></a>
            <div class="" style="margin-top: 2%; padding-bottom: 2%;">
                <h3 class="custom-card-title">Transaction Details</h3>
                <p class="custom-card-title">
                    Sent to : <?php echo e($htrans->address); ?>

                </p>
                <p class="custom-card-title">
                    Purchase date : <?php echo e(\Carbon\Carbon::parse($htrans->purchase_date)->format('d F Y - H:i')); ?>

                </p>
            </div>
            <div class="container">
                <div class="row" style="text-align: center;">
                    <div class="col-md-2">

                    </div>
                    <div class="col-md-2">
                        <h3 class="custom-card-title">Name</h3>
                    </div>
                    <div class="col-md-1">
                        <h3 class="custom-card-title">Qty</h3>
                    </div>
                    <div class="col-md-2">
                        <h3 class="custom-card-title">Price</h3>
                    </div>
                    <div class="col-md-1">
                        <h3 class="custom-card-title">Discount</h3>
                    </div>
                    <div class="col-md-3">
                        <h3 class="custom-card-title">Subtotal</h3>
                    </div>
                    <div class="col-md-1">
                        <h3 class="custom-card-title">Action</h3>
                    </div>
                </div>
                <?php $__currentLoopData = $listDtrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row" style="padding: 2% 0; color: white; text-align: center; display: flex; align-items: center; background-color: #cda45e; border-bottom: 2px solid">
                        <div class="col-md-2">
                            <a href="<?php echo e(route('detail', ['id' => $d->Item->ID_items])); ?>">
                                <img src="<?php echo e($d->Item->img); ?>" alt="" class="img-thumbnail">
                            </a>
                        </div>
                        <div class="col-md-2">
                            <a href="<?php echo e(route('detail', ['id' => $d->Item->ID_items])); ?>">
                                <p style="color: white"><?php echo e($d->Item->name); ?></p>
                            </a>
                        </div>
                        <div class="col-md-1">
                            <p>Qty: <?php echo e($d->qty); ?></p>
                        </div>
                        <div class="col-md-2">
                            <p>Rp <?php echo e(number_format($d->price, 0, ',', '.')); ?></p>
                        </div>
                        <div class="col-md-1">
                            <p>
                                <?php if($d->discount != 0): ?>
                                    <?php echo e($d->discount); ?>%
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-3">
                            <p>Rp <?php echo e(number_format($d->subtotal, 0, ',', '.')); ?></p>
                        </div>
                        <div class="col-md-2">
                            <p>
                                <a href="<?php echo e(route('return-items', ['id' => $d->Item->ID_items])); ?>" style="color:red">Return</a>
                            </p>
                        </div>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="" id="" style="text-align: right; color: white">
                    <div class="row">
                        <div class="col-md-9">

                        </div>
                        <div class="col-md-3">
                            <p class="custom-card-title">
                                Total : Rp <?php echo e(number_format($htrans->total, 0, ',', '.')); ?> via <?php echo e($htrans->Payment->name); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="return-form-container" style="display:none; padding: 2%; border:1px white; margin-top: 20px;">
                <form id="return-form" method="POST" action="<?php echo e(route('process-return')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="return-item-id">
                    <div class="form-group">
                        <label for="return-item-name">Item Name</label>
                        <input type="text" id="return-item-name" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label for="return-item-qty">Quantity</label>
                        <input type="number" id="return-item-qty" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label for="return-reason">Reason for Return</label>
                        <textarea name="reason" id="return-reason" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Return</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
    const returnFormContainer = document.getElementById('return-form-container');
    const returnForm = document.getElementById('return-form');
    const returnItemId = document.getElementById('return-item-id');
    const returnItemName = document.getElementById('return-item-name');
    const returnItemQty = document.getElementById('return-item-qty');
    const returnReason = document.getElementById('return-reason');

    // Fungsi untuk fetch data
    function fetchReturnData(itemId) {
        fetch(`/return-items/${itemId}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                    return;
                }

                // Populate form
                returnItemId.value = data.id;
                returnItemName.value = data.name;
                returnItemQty.value = data.qty;
                returnReason.value = '';

                // Tampilkan form
                returnFormContainer.style.display = 'block';
            })
            .catch(err => {
                console.error('Error fetching return data:', err);
                alert('Something went wrong. Please try again later.');
            });
    }

    // Tambahkan event listener ke setiap link
    document.querySelectorAll('a[href*="return-items"]').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const itemId = this.getAttribute('href').split('/').pop();
            fetchReturnData(itemId);
        });
    });
});

</script>


<?php echo $__env->make('layout.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\user\history.blade.php ENDPATH**/ ?>