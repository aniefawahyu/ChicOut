<?php
$total = 0; // Initialize the total variable
?>
<?php $__currentLoopData = $listCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="">
<div class="row g-0 isi-cart p-5">
    <div class="col-md-2" style="padding-left: 0px !important; margin: auto 0">
        <img src="<?php echo e($item->Item->img); ?>" class="img-thumbnail rounded-start" alt="...">
    </div>
    <div class="col-md-7">
        <a href="<?php echo e(route('detail', ['id' => $item->ID_items])); ?>" class="">
            <h5 class="custom-card-title"><?php echo e($item->Item->name); ?></h5>
            <p><?php echo e(implode(' ', array_slice(explode(' ', $item->Item->description), 0, 20))); ?>..
            </p>
        </a>
        <?php if($item->Item->discount != 0): ?>
            
            <h3 class="custom-card-title">
                <span>Rp
                    <?php echo e(number_format(floor($item->Item->price - ($item->Item->price * $item->Item->discount) / 100), 0, ',', '.')); ?></span><br>
                <small><span
                        style="background-color: #d43f3a; color: white; border-radius: 10%; padding: 1% 1%"><?php echo e($item->Item->discount); ?>%</span>
                    <del>Rp <?php echo e(number_format($item->Item->price, 0, ',', '.')); ?></del></small>
            </h3>
        <?php else: ?>
            
            <h3 class="custom-card-title">Rp
                <?php echo e(number_format($item->Item->price, 0, ',', '.')); ?></h3>
        <?php endif; ?>
    </div>
    <div class="col-md-3" style="margin: auto 0">
        <div class="" style="margin: auto 0; display: flex">
            <?php if($item->Item->discount != 0): ?>
                <?php
                    $subtotal = floor($item->Item->price - (($item->Item->price * $item->Item->discount) / 100)) * $item->qty;
                    $total += $subtotal; // Add the subtotal to the total
                ?>
            <?php else: ?>
                
                <?php
                    $subtotal = $item->Item->price * $item->qty;
                    $total += $subtotal; // Add the subtotal to the total
                ?>
            <?php endif; ?>
            <div style="margin: 5px;">
                <p>Qty: <input type="number" min="1" data-idcart="<?php echo e($item->ID_cart); ?>"
                        name="qty" class="qty" value="<?php echo e($item->qty); ?>"
                        style="color: black; padding: 4.5px; border-radius: 5px">
                </p>
            </div>
            <div style="margin: auto 0">
                <button class="btn btn-danger" value="<?php echo e($item->ID_cart); ?>" name="delete"><i
                        class="icon-trash2"></i></button>

            </div>
        </div>
        <div style="margin-left: 5px;">
            <p>
                Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?>

            </p>
        </div>
    </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row isi-cart" style="margin-bottom: 2%; padding-bottom: 2%;">
<div class="col-md-9"></div>
<div class="col-md-3">
    <h3 id="total" class="custom-card-title">Total: Rp <?php echo e(number_format($total, 0, ',', '.')); ?></h3>
</div>
</div>
<?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\user\partial-cart.blade.php ENDPATH**/ ?>