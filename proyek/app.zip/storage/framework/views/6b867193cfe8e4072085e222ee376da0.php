<?php $__env->startSection('title'); ?>
    Chic Out - SignIn SignUp
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>
    <div class="fh5co-loader-wrapper">
        <div class="fh5co-loader"></div>
    </div>

    <div class="section-body">
        <div class="main">

            <input type="checkbox" id="chk" aria-hidden="true">
            <?php if(Session::has('pesan')): ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: '<?php echo e(Session::get('pesan')); ?>',
                        customClass: {
                            confirmButton: 'btn btn-danger',
                            container: 'my-swal'
                        }
                    });
                </script>
                <style>
                    
                    .my-swal .swal2-confirm {
                        margin: 1em;
                    }
                </style>
            <?php endif; ?>

            <?php if(Session::has('sukses')): ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    
                    Swal.fire({
                        icon: 'success',
                        title: 'Yay...',
                        text: '<?php echo e(Session::get('sukses')); ?>',
                        customClass: {
                            confirmButton: 'btn btn-success',
                            container: 'my-swal'
                        }
                    });
                </script>
                <style>
                    
                    .my-swal .swal2-confirm {
                        margin: 1em;
                    }
                </style>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: '<?php echo e($errors->first()); ?>',
                        customClass: {
                            confirmButton: 'btn btn-danger',
                            container: 'my-swal'
                        }
                    });
                </script>
                <style>
                    
                    .my-swal .swal2-confirm {
                        margin: 1.25em;
                    }
                </style>
            <?php endif; ?>
            <div class="signup">
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <label for="chk" aria-hidden="true">Sign up</label>
                    <input type="text" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>">
                    <input type="text" name="display_name" placeholder="Display Name" value="<?php echo e(old('display_name')); ?>">
                    <input type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <input type="password" name="password" placeholder="Password">
                    <input type="password" name="confirmPassword" placeholder="Confirm Password">
                    <input type="text" name="tel" placeholder="Nomor Telepon" value="<?php echo e(old('tel')); ?>">
                    <input type="text" name="address" placeholder="Address" value="<?php echo e(old('address')); ?>">
                    <button type="submit" name="register" class="btn btn-success">Register</button>
                </form>
            </div>
            <div class="login">
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <label for="chk" aria-hidden="true">Sign In</label>
                    <input type="text" name="loginUsername" placeholder="Username"
                        value="<?php echo e(old('loginUsername')); ?>">
                    <input type="password" name="loginPassword" placeholder="Password">
                    <button type="submit" name="login" class="btn btn-login">Login</button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.pagelogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\login-register.blade.php ENDPATH**/ ?>