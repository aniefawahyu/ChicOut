<?php $__env->startSection('title'); ?>
    ChicOut 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
    <li class="<?php echo e(request()->is('ChicOut/Category/Men') ? 'active' : ''); ?>">
        <a href="<?php echo e(url('ChicOut/Category/Men')); ?>" 
        style="background-image: url('<?php echo e(asset('image/Men.jpeg')); ?>')">
            Men
        </a>
    </li>
    <li class="<?php echo e(request()->is('ChicOut/Category/Women') ? 'active' : ''); ?>">
        <a href="<?php echo e(url('ChicOut/Category/Women')); ?>" 
        style="background-image: url('<?php echo e(asset('image/Women.jpeg')); ?>')">
            Women
        </a>
    </li>
    <li class="<?php echo e(request()->is('ChicOut/Category/Kids') ? 'active' : ''); ?>">
        <a href="<?php echo e(url('ChicOut/Category/Kids')); ?>" 
        style="background-image: url('<?php echo e(asset('image/Kids.jpeg')); ?>')">
            Kids
        </a>
    </li>
    

    
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'master'): ?>
            <li><a href="<?php echo e(route('master-home')); ?>">Master</a></li>
        <?php else: ?>
            <li><a href="<?php echo e(route('cart')); ?>">Cart</a></li>
            <li><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div id="page">
        <header id="fh5co-header" class="fh5co-cover js-fullheight" role="banner"
        
            style="background-image: url(<?php echo e($selectedCategory->img); ?>);"
            data-stellar-background-ratio="0.5">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="display-t js-fullheight">
                            <div class="display-tc js-fullheight animate-box" data-animate-effect="fadeIn">
                                <h1><?php echo e($selectedCategory->name); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div class="container mt-4">
            <div class="row">
                <?php $__currentLoopData = $listItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('detail', ['id' => $item->ID_items])); ?>">
                        <div class="col-md-4">
                            <div class="custom-card box" data-aos="zoom-in" data-aos-delay="200">
                                <img src="<?php echo e($item->img); ?>" class="custom-card-img img-thumbnail"
                                    alt="<?php echo e($item->name); ?>">
                                <div class="custom-card-body ">
                                    <h3 class="custom-card-title"><?php echo e($item->name); ?></h3>
                                    <p class="custom-card-text">
                                        <?php echo e(implode(' ', array_slice(explode(' ', $item->description), 0, 20))); ?>...
                                    </p>
                                    <?php if($item->discount != 0): ?>
                                        <?php
                                            $priceDiscount = floor(($item->price - ($item->price * $item->discount) / 100));
                                        ?>

                                        <h3 class="custom-card-title">
                                            <span>Rp <?php echo e(number_format($priceDiscount, 0, ',', '.')); ?></span><br>
                                            <small>
                                                <span style="background-color: #d43f3a; color: white; border-radius: 10%; padding: 1% 1%"><?php echo e($item->discount); ?>%</span> <del>Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></del>
                                            </small>
                                        </h3>
                                    <?php else: ?>
                                        <h3 class="custom-card-title">Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></h3>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div style="margin-top: 20px;"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\user\category.blade.php ENDPATH**/ ?>