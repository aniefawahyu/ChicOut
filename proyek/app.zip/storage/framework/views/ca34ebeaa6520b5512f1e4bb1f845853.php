<?php $__env->startSection('title'); ?>
    ChicOut - <?php echo e(Auth::user()->display_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <li>
        <a href="<?php echo e(url('ChicOut/Category/Men')); ?>">Men</a>
    </li>
    <li>
        <a href="<?php echo e(url('ChicOut/Category/Women')); ?>">Women</a>
    </li>
    <li>
        <a href="<?php echo e(url('ChicOut/Category/Kids')); ?>">Kids</a>
    </li>
    

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'master'): ?>
            <li><a href="<?php echo e(route('master-home')); ?>">Master</a></li>
        <?php else: ?>
            <li><a href="<?php echo e(route('cart')); ?>">Cart</a></li>
            <li class="active"><a href="<?php echo e(route('profile')); ?>">Profile</a></li>
        <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page">
            <br><br><br><br>
            <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger"><b>Logout</b></a>
            <?php if($errors->any()): ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: '<?php echo e($errors->first()); ?>',
                        customClass: {
                            confirmButton: 'btn btn-danger',
                            container: 'my-swal'
                        }
                    });
                </script>
                <style>
                    .my-swal .swal2-confirm {
                        margin: 1.25em;
                    }
                </style>
            <?php endif; ?>
            <?php if(Session::has('sukses')): ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Yay...',
                        text: '<?php echo e(Session::get('sukses')); ?>',
                        customClass: {
                            confirmButton: 'btn btn-success',
                            container: 'my-swal'
                        }
                    });
                </script>
                <style>
                    .my-swal .swal2-confirm {
                        margin: 1em;
                    }
                </style>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <form method="post">
                        <?php echo csrf_field(); ?>
                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username:</label>
                                <input type="text" name="username" class="form-control"
                                    value="<?php echo e(Auth::user()->username); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="display_name" class="form-label">Display Name:</label>
                                <input type="text" name="display_name" class="form-control"
                                    value="<?php echo e(Auth::user()->display_name); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="text" name="email" class="form-control"
                                    value="<?php echo e(Auth::user()->email); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Current Password:</label>
                                <input type="password" name="password" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="newPassword" class="form-label">New Password:</label>
                                <input type="password" name="newPassword" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="tel" class="form-label">Tel:</label>
                                <input type="text" name="tel" class="form-control" value="<?php echo e(Auth::user()->tel); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address:</label>
                                <input type="text" name="address" class="form-control"
                                    value="<?php echo e(Auth::user()->address); ?>">
                            </div>
                            <br>
                            <button type="submit" class="btn btn-success"><b>Update</b></button>
                            <br><br>
                        </form>
                    </form>
                </div>
                <!-- Kolom Pertama: Profile Card -->
                <div class="col-md-6">
                    <div class="custom-card-history">
                        <div class="card-profile-kiri">
                            <img src="<?php echo e(asset('image/profile.svg')); ?>">
                        </div>
                    </div>
                </div>
            </div>


            <div class="custom-card-history">
                <h3 class="custom-card-title">Purchase History <br></h3>
                
                    
                
                
                <?php if(count($listHtrans) <= 0): ?>
                    <h4 class="custom-card-title">
                        It seems like you haven't made a purchase yet. Start shopping now!
                    </h4>
                <?php else: ?>
                    <?php $__currentLoopData = $listHtrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('dtrans', ['id' => $h->ID_htrans])); ?>" style="color: white">
                            <div class="row" style="padding: 2% 0; background-color: #cda45e; text-align: center; border-bottom: 2px solid">
                                <div class="col-md-4">
                                    <?php echo e(\Carbon\Carbon::parse($h->purchase_date)->format('d F Y - H:i')); ?>

                                </div>
                                <div class="col-md-3">
                                    Rp <?php echo e(number_format($h->total, 0, ',', '.')); ?>

                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\user\profile.blade.php ENDPATH**/ ?>