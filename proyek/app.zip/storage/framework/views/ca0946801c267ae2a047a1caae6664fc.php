<?php $__env->startSection('title'); ?>
    Chicout - Accounts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <li>
        <a href="<?php echo e(route('master-home')); ?>">Home</a>
    </li>
    <li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
        <a href="<?php echo e(route('master-item', ['name' => 'All'])); ?>">Items</a>
        <ul class="dropdown">
            <?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('master-item', ['name' => $c->name])); ?>"><?php echo e($c->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
    <li>
        <a href="<?php echo e(route('master-category')); ?>">Categories</a>
    </li>
    <li>
        <a href="<?php echo e(route('master-payment')); ?>">Payments</a>
    </li>
    <li class="has-dropdown active" style="color:rgba(255, 255, 255, 0.7)">
        <a href="<?php echo e(route('master-account', ['search'=>'All'])); ?>">Accounts</a>
        <ul class="dropdown">
            <li>
                <a href="<?php echo e(route('master-account', ['search'=>'Master'])); ?>">Master</a>
            </li>
            <li>
                <a href="<?php echo e(route('master-account', ['search'=>'User'])); ?>">User</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="<?php echo e(route('master-profile')); ?>">Profile</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('sukses')): ?>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Yay...',
                text: '<?php echo e(Session::get('sukses')); ?>',
                customClass: {
                    confirmButton: 'btn btn-success',
                    container: 'my-swal'
                }
            });
        </script>
        <style>
            .my-swal .swal2-confirm {
                margin: 1em;
            }
        </style>
    <?php endif; ?>
    <div class="box" style="margin-top: 15%; margin-bottom: 2%;">
        <div class="row">
            <div class="col-md-10">
                <h3 class="custom-card-title">Account Information</h3>
                <p class="custom-card-title">
                    Username : <?php echo e($acc->username); ?>

                </p>
                <p class="custom-card-title">
                    Display Name : <?php echo e($acc->display_name); ?>

                </p>
                <p class="custom-card-title">
                    Email : <?php echo e($acc->email); ?>

                </p>
                <p class="custom-card-title">
                    Tel : <?php echo e($acc->tel); ?>

                </p>
                <p class="custom-card-title">
                    Address : <?php echo e($acc->address); ?>

                </p>
            </div>
            <div class="col-md-2" style="text-align: end">
                <a href="<?php echo e(route('master-account', ['search' => 'All'])); ?>" class="btn btn-primary"><i class="icon-back"></i></a>
            </div>
        </div>
    </div>
    <h1 style="color: white">Transaction History</h1>
    <table class="table" style="background-color: #1a1814">
        <tr style="font-weight: bold; color: white;">
            <th style="border-right: 2px solid; border-left: 2px solid; text-align: center">Purchase Date</th>
            <th style="border-right: 2px solid; text-align: center">Total</th>
            <th style="border-right: 2px solid; text-align: center">Payment</th>
            <th style="border-right: 2px solid; text-align: center">Sent To</th>
        </tr>
        <?php $__currentLoopData = $htrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center" style="color: white; border-bottom: 2px solid">
            <td style="border-right: 2px solid; border-left: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    <?php echo e(\Carbon\Carbon::parse($h->purchase_date)->format('d F Y - H:i')); ?>

                </a>
            </td>
            <td style="border-right: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    Rp <?php echo e(number_format($h->total, 0, ',', '.')); ?>

                </a>
            </td>
            <td style="border-right: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    <?php echo e($h->Payment->name); ?>

                </a>
            </td>
            <td style="border-right: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    <?php echo e(implode(' ', array_slice(explode(' ', $h->address), 0, 5))); ?>...
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.crud', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views\master\account-detail.blade.php ENDPATH**/ ?>