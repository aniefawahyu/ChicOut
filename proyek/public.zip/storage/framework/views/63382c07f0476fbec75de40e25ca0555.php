<?php $__env->startSection('title'); ?>
ChicOut - Master
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
<li class="active">
    <a href="<?php echo e(route('master-home')); ?>">Home</a>
</li>
<li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
    <a href="<?php echo e(route('master-item', ['name' => 'All'])); ?>">Items</a>
    <ul class="dropdown">
        <?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('master-item', ['name' => $c->name])); ?>"><?php echo e($c->name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</li>
<li>
    <a href="<?php echo e(route('master-category')); ?>">Categories</a>
</li>
<li>
    <a href="<?php echo e(route('master-payment')); ?>">Payments</a>
</li>
<li class="has-dropdown" style="color:rgba(255, 255, 255, 0.7)">
    <a href="<?php echo e(route('master-account', ['search'=>'All'])); ?>">Accounts</a>
    <ul class="dropdown">
        <li>
            <a href="<?php echo e(route('master-account', ['search'=>'Master'])); ?>">Master</a>
        </li>
        <li>
            <a href="<?php echo e(route('master-account', ['search'=>'User'])); ?>">User</a>
        </li>
    </ul>
</li>
<li>
    <a href="<?php echo e(route('master-profile')); ?>">Profile</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<?php if($errors->any()): ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: '<?php echo e($errors->first()); ?>',
        customClass: {
            confirmButton: 'btn btn-danger',
            container: 'my-swal'
        }
    });
</script>
<style>
    .my-swal .swal2-confirm {
        margin: 1.25em;
    }
</style>
<?php endif; ?>
<div class="container" style="margin-top: 15%">
    <form action="" method="post">
        <div class="row">
            <div class="col-md-2">
                Start Date:
                <input type="date" name="startDate" id="" style="color: black" value="<?php echo e(old('startDate')); ?>">
            </div>
            <div class="col-md-2">
                End Date:
                <input type="date" name="endDate" id="" style="color: black" value="<?php echo e(old('endDate', now()->format('Y-m-d'))); ?>">
            </div>
            <div class="col-md-4">
                <br>
                <button type="submit" class="btn btn-primary" style="height: 100%"><i class='icon-search'></i></button>
            </div>
        </div>
        <?php echo csrf_field(); ?>
    </form><br>
    <h2 style="color: white">Period : <?php echo e($period); ?> </h2>
    <div class="row" style="text-align: center; background-color:white; padding: 2% 0;">
        <div class="col-md-8" style="margin: 2% 0">
            <h3>Total Income per Day</h3>
            <?php echo $totalIncome->container(); ?>

            <script src="<?php echo e($totalIncome->cdn()); ?>"></script>
            <?php echo e($totalIncome->script()); ?>

        </div>
        <div class="col-md-4">
            <h3>Top-Selling Items by Category</h3>
            <?php echo $topSellingCategory->container(); ?>

            <script src="<?php echo e($topSellingCategory->cdn()); ?>"></script>
            <?php echo e($topSellingCategory->script()); ?>

        </div>
    </div><br>
    <h1 style="color: white">Transaction List</h1>
    <table class="table" style="background-color: #1a1814">
        <tr style="font-weight: bold; color: white; border-bottom: 2px solid">
            <th style="border-right: 2px solid; border-left: 2px solid; text-align: center">Name</th>
            <th style="border-right: 2px solid; text-align: center">Purchase Date</th>
            <th style="border-right: 2px solid; text-align: center">Total</th>
            <th style="border-right: 2px solid; text-align: center">Payment</th>
        </tr>
        <?php $__currentLoopData = $htrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center" style="color: white; border-bottom: 2px solid">
            <td style="border-right: 2px solid; border-left: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    <?php echo e($h->Account->display_name); ?>

                </a>
            </td>
            <td style="border-right: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    <?php echo e(\Carbon\Carbon::parse($h->purchase_date)->format('d F Y - H:i')); ?>

                </a>
            </td>
            <td style="border-right: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    Rp <?php echo e(number_format($h->total, 0, ',', '.')); ?>

                </a>
            </td>
            <td style="border-right: 2px solid; vertical-align: middle">
                <a href="<?php echo e(route('master-dtrans', ['id'=>$h->ID_htrans])); ?>" style="color: white">
                    <?php echo e($h->Payment->name); ?>

                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.crud", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flore\OneDrive\Dokumen\GitHub\ChicOut\proyek\resources\views/master/home.blade.php ENDPATH**/ ?>